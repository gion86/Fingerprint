//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SDK_DEMO.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_SDK_DEMO_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDC_COMBO_COM                   998
#define IDC_COMBO_BAUDRATE              999
#define IDC_BUTT_OPEN                   1000
#define IDC_BUTT_CLOSE                  1001
#define IDC_EDIT_ID                     1002
#define IDC_SPIN_ID                     1003
#define IDC_BUTT_ENROLL                 1004
#define IDC_BUTT_VERIFY                 1005
#define IDC_BUTT_IDENTIFY               1006
#define IDC_BUTT_VERIFY_TEMPLATE        1007
#define IDC_BUTT_IDENTIFY_TEMPLATE      1008
#define IDC_BUTT_ISPRESSFP              1009
#define IDC_BUTT_GET_IMAGE              1010
#define IDC_BUTT_GET_RAWIMAGE           1011
#define IDC_BUTT_GET_USER_COUNT         1012
#define IDC_BUTT_DELETE                 1013
#define IDC_BUTT_DELETE_ALL             1014
#define IDC_BUTT_GET_TEMPLATE           1015
#define IDC_BUTT_SET_TEMPLATE           1016
#define IDC_BUTT_GET_DATABASE           1017
#define IDC_BUTT_SET_DATABASE           1018
#define IDC_BUTT_FW_UPGRADE             1019
#define IDC_BUTT_ISO_UPGRADE            1020
#define IDC_BUTT_GET_LIVEIMAGE          1021
#define IDC_BUTT_SAVE_IMAGE             1022
#define IDC_BUTT_CANCEL                 1024
#define IDC_PROGRESS1                   1051
#define IDC_STATIC_RESULT               1052

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1025
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
